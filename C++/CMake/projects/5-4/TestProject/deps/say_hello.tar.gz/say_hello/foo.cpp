#include "foo.h"

std::string sayHello(const std::string& name) {
    return "Hello, " + name;
}
