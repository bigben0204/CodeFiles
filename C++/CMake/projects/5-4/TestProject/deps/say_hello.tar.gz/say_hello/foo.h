#ifndef TESTPROJECT_FOO_H
#define TESTPROJECT_FOO_H

#include <string>

std::string sayHello(const std::string& name);

#endif //TESTPROJECT_FOO_H
